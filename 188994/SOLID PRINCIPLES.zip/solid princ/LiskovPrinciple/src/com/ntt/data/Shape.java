package com.ntt.data;

public abstract class Shape {
abstract int getArea();
}

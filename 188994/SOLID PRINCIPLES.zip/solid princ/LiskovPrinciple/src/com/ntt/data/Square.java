package com.ntt.data;


public class Square extends Shape {
	private int size;
	public int getWidth() {
		return size;
	}
	public void setsize(int size) {
		this.size = size;
	}
	
	int getArea(){
		return size*size;
	}
}

package com.ntt.data;

public class LSPDemo {
	
	
public static void PrintInfo(Shape r){
	System.out.println("Result should  be 24.right? the result is"+r.getArea());
}
	public static void main(String[] args) {
		
	
		
Rectangle s=new Rectangle();
s.setWidth(3);
s.setWidth(7);
PrintInfo(s);
	}
	private static void PrintInfo(Rectangle s) {
		// TODO Auto-generated method stub
		
	}

}

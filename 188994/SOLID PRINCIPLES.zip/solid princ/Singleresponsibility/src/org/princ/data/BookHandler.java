package org.princ.data;

public interface BookHandler {
public void print();
public void save();
}

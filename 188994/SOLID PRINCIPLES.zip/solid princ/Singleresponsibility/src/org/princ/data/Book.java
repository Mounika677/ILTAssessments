package org.princ.data;

public class Book implements BookHandler {
private int noofpages;
private String authorname;
public Book(String authorname, int noofpages)
{
	this.authorname=authorname;
	this.noofpages=noofpages;
}
public int getNoofpages() {
	return noofpages;
}
public void setNoofpages(int noofpages) {
	this.noofpages = noofpages;
}
public String getAuthorname() {
	return authorname;
}
public void setAuthorname(String authorname) {
	this.authorname = authorname;
}
public void print(){
	System.out.println("printing the book");
}
public void save(){
	System.out.println("saving the book");
}

public String toString(){
	return authorname+"="+ noofpages;
	
}


}

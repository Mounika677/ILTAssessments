package org.princ.data;

public interface Deque <T>{
	public T poll();
	public T peek();

}

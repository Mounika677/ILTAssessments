package org.princ.data;

public interface List<T> {
	 
	
		public T get();
		public void add(T t);
}
		
	 

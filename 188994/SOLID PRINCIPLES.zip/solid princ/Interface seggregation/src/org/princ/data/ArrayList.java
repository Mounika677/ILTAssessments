package org.princ.data;

public class ArrayList implements List<Integer>{

	@Override
	public Integer get() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void add(Integer t) {
		// TODO Auto-generated method stub
		
	}
	

}

package org.princ.data;
public class LinkedList implements List<Integer>,Deque<Integer>{

	@Override
	public Integer poll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Integer peek() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Integer get() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void add(Integer t) {
		// TODO Auto-generated method stub
		
	}


 }
 

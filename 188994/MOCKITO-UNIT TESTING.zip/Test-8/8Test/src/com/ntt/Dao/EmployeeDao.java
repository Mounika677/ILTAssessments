

	
	
	
	
	
	package com.ntt.Dao;

import java.util.List;

import com.ntt.Model.Employee;

public interface EmployeeDao  {
	Employee getByEmployeeId(int id);
	Employee createEmployee();
	Employee deleteEmployee(int id);
	List<Employee> list();
	Employee searchEmployeeByName(String name);
	}
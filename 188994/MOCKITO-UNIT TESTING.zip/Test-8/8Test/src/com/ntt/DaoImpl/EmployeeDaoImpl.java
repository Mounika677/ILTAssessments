package com.ntt.DaoImpl;

import java.util.List;

import com.ntt.Dao.EmployeeDao;
import com.ntt.Model.Employee;

public class EmployeeDaoImpl implements EmployeeDao{

	@Override
	public Employee getByEmployeeId(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Employee createEmployee() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Employee deleteEmployee(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Employee> list() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Employee searchEmployeeByName(String name) {
		// TODO Auto-generated method stub
		return null;
	}
	
	

}

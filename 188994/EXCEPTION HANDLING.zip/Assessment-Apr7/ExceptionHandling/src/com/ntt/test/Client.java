package com.ntt.test;
	import java.util.Scanner;
	public class Client {
		static Scanner scanner=new Scanner(System.in);
		

		@SuppressWarnings("resource")
		public static void main(String[] args) throws InsufficientAmount{
			// TODO Auto-generated method stub
			System.out.println("WELCOME");
			System.out.println("Press the following to get into it\n1.Create Account\n2.Amount Transfer\n3.Quit");
			Scanner scanner=new Scanner(System.in);
			int choice=scanner.nextInt();
			if(choice==1)
			{
				System.out.println("Enter your choice\n1.Create Account\n2.Repeat Account Creation\n3.Quit");
				int input=scanner.nextInt();
				if(input==1)
				{
				System.out.println("Enter User Name");
				String userName=scanner.next();
				System.out.println("Enter User Address");
				String userAddress=scanner.next();
				System.out.println("Enter Account Id");
				int acctId=scanner.nextInt();
				System.out.println("Enter Account Balance");
				double acctBalance=scanner.nextDouble();
				System.out.println("Enter your SecretPin");
				int acctPin=scanner.nextInt();
				Account acct=new Account(acctId, acctBalance);
				User user=new User(userName, acct);
			   
			    System.out.println("Account created Successfully");
			    }
				else if(input==2)
				{
					main(args);
				}
				else if(input==3)
				{
					System.exit(0);
				}
				else
				{
					System.out.println("Invalid Choice..");
				}
			}
			else if(choice==2)
			{
				System.out.println("Enter your Choice\n1.Transfer amount\n2.quit");
				int ip=scanner.nextInt();
				if(ip==1)
				{					
									Account acct1=new Account(1,2300);
									User user1=new User("user1", acct1);
									Account acct2=new Account(1,5000);
									User user2=new User("user2", acct2);
									System.out.println(user1);
									System.out.println(user2);
									System.out.println("enter your choice 1.from user1 to user2\n2.user2 to user1\n3.Quit");
									int n=scanner.nextInt();
									if(n==1) {
									System.out.println("Enter the amount to be transfered");
									double amount=scanner.nextDouble();
								    Bank bank=new Bank();
									bank.transfer(user1, user2, amount);
									System.out.println("TRANSFER SUCCESSFULL!!!!!!!!!");
									System.out.println("After transfer");
									System.out.println(user1);
									System.out.println(user2);}
									else if(n==2)
									{

										System.out.println("Enter the amount to be transfered");
										double amount=scanner.nextDouble();
									    Bank bank=new Bank();
										bank.transfer(user2, user1, amount);
										System.out.println("TRANSFER SUCCESSFULL!!!!!!!!!");
										System.out.println("After transfer");
										System.out.println(user1);
										System.out.println(user2);

				}
									else
									{
										System.exit(0);
									}
								
						
					

			}
			else if(choice==3)
			{
				System.exit(0);
			}
			else {
				System.out.println("Invalid Choice...");
			}
		}
		}
	}



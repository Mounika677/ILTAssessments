package com.ntt.test;

	public class InsufficientAmount extends Exception {
		public InsufficientAmount(String message)
		{
			super(message);
		}
	}



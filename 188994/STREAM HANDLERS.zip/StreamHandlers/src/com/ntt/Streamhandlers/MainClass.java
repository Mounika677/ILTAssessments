package com.ntt.Streamhandlers;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;
public class MainClass {
	 
public static void main(String args[]) {
	
    List<Employee> empList = new ArrayList<>();
    empList.add(new Employee("varsha",10,40000));
    empList.add(new Employee("ridhvi",20, 15000));
    empList.add(new Employee("ganesh",30, 25000));
    empList.add(new Employee("shanvi",40, 10000));

    // find employees whose salaries are above 10000
    empList.stream().filter(emp->emp.getSalary() > 10000).forEach(System.out::println);
    long i=empList.stream().filter(emp->emp.getSalary()>10000).count();
    System.out.println("count of employees whose salary is greater than 10000 is="+i);
}
		    
		    
		    
	}
package com.fd;

public class Nokia extends Mobile{

	@Override
	public double getTax() {
		return 7;
		
	}

}

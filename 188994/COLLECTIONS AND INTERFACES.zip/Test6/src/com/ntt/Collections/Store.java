package com.ntt.Collections;

import java.util.ArrayList;

public class Store{
public static void main(String args[]){

	Employee emp1=new Employee(001,"Mounika",07,"Hyderabad",784,793538953,"monica@gmail.com");
    Employee emp2=new Employee(002,"Priyanka",03,"Secunderabad",879,53535353,"priya@gmail.com");
    Employee emp3=new Employee(003,"Geetha",05,"Ramnagar",432,53598593,"geetha@gmail.com");
	
	ArrayList<Employee> List=new ArrayList<Employee>();
	List.add(emp1);
	List.add(emp2);
	List.add(emp3);
	 for(Employee emp: List)
	 {
		 System.out.println(emp);
	 }
	
	
}
}



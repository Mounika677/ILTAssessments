package com.ntt.Collections;

public class Employee {

	
	private int empId;
	private String name;
	private int grade;
	private String address;
	private double salary;
	private double mobileno;
	private String email;
	
	public Employee(int empId,String name,int grade,String address,double salary,double mobileno,String email)
	{
		this.empId=empId;
		this.name=name;
		this.grade=grade;
		this.address=address;
		this.salary=salary;
		this.mobileno=mobileno;
		this.email=email;
		
	}
	public String toString() {
		return "Employee[id="+empId+ ",Name=" +name+ ",grade=" +grade+ ",Address= "+address+ ",Salary= "+salary+ ",Mobilenum= "+mobileno+ ",Email= "+email+ "]";
		
	}
	}


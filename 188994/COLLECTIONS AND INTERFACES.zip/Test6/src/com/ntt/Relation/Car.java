package com.ntt.Relation;

import java.util.Scanner;

public class Car extends Vehicle {

	
	public void CarDemo() {

		EngineFactory engine =  new EngineFactory();
		
		Scanner s= new Scanner(System.in);
		System.out.println("Press 1. to start car  2. to stop car  press q to exit from the car");
	int n  = s.nextInt();
	
	if(n==1) {
		engine.start();
		
		
	}
	
	if(n==2) {
		
		engine.stop();
	}
	else
	{
		System.exit(0);
	}
	}}

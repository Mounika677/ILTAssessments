package com.ntt.Relation;
public class EngineFactory {
	public void start()
	{
		System.out.println("Started");
	}
	public void stop()
	{
		System.out.println("Stopped");
	}
	}

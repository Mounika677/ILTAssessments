package com.ntt.Relation;
import java.util.Scanner;

	public class VehicleFactory {

		public static void main(String[] args) {
			// TODO Auto-generated method stub

			
			
			Scanner scanner= new Scanner(System.in);
			System.out.println("====WELCOME TO VEHICLE SIMULATION======");
			System.out.println("Press 1. Car  2.Bike  3. Bus  4. Quit");
			int n= scanner.nextInt();
			
			if(n==1) {
				Car c = new Car();
				c.setNumber(2345);
				c.setName("Mecedes Benz");
				c.setPrice(10000000);
				c.setColor("black");
				c.vehicleInfo();
				c.CarDemo();
			}
			
			if(n==2) {
				Bike b = new Bike();
				b.setNumber(4567);
				b.setName("Enfield");
				b.setPrice(200000);
				b.setColor("black");
				b.vehicleInfo();
				b.BikeDemo();
			}
			
			if(n==3) {
				Bus bu = new Bus();
				bu.setNumber(2333);
				bu.setName("Volvo");
				bu.setPrice(1000000);
				bu.setColor("White");
				bu.vehicleInfo();
				bu.BusDemo();
				
			}
			
			if(n==4) {
				System.exit(0);
			}
		}

	}



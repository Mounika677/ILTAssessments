package com.ntt.Relation;
public class Vehicle {
		private int number;
	private String name;
	private int price;
	private String color;

	public void vehicleInfo()
	{
		System.out.println("Vehicle number:" +number+ "Name:" +name+ "price:" +price+ "color" +color);
		
	}
	public void setNumber(int number)
	{
		this.number = number;
	}
	public void setName(String name) {
		this.name = name;
	}

	public void setPrice(int price)
	{
		this.price = price;
	}
	public void setColor(String color)
	{
		this.color = color;
	}

	}



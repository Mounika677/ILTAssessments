package com.ntt.Relation;

import java.util.Scanner;

public class Bus extends Vehicle{
	public void BusDemo() {

		EngineFactory engine =  new EngineFactory();
		
		Scanner s= new Scanner(System.in);
		System.out.println("Press 1. to start bus  2. to stop bus  press q to exit from the bus");
	int n  = s.nextInt();
	
	if(n==1) {
		engine.start();
		
		
	}
	
	if(n==2) {
		
		engine.stop();
	}
	else
	{
		System.exit(0);
	}
	}}



package com.ntt.Relation;

import java.util.Scanner;

public class Bike extends Vehicle {

	public void BikeDemo() {

		EngineFactory engine =  new EngineFactory();
		
		Scanner s= new Scanner(System.in);
		System.out.println("Press 1. to start bike  2. to stop bike  press q to exit from the bike");
	int n  = s.nextInt();
	
	if(n==1) {
		engine.start();
		
		
	}
	
	if(n==2) {
		
		engine.stop();
	}
	else
	{
		System.exit(0);
	}
	}}

